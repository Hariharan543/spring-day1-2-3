package com.dsrc.beans;

public class EmployeeBean {
	private int empno;
	private String name;
	private String city;
	private DepartmentBean db;
	
	public EmployeeBean(){
		
	}
	
	public EmployeeBean(int empno, String name, String city, DepartmentBean db)
	
	{
		this.empno=empno;
		this.name=name;
		this.city=city;
		this.setDepartmentBean(db);
		
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public DepartmentBean getDb() {
		return db;
	}

	public void setDb(DepartmentBean db) {
		this.db = db;
	}

	private void setDepartmentBean(DepartmentBean db2) {
		// TODO Auto-generated method stub
		
	}

}
