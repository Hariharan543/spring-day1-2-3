package com.dsrc.beans;

public class DepartmentBean {
	private int deptno;
	private String deptName;
	
	public DepartmentBean(){}
	
	public DepartmentBean(int dno, String dname)
	{
		this.deptno=dno;
		this.deptName=dname;
		
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}
