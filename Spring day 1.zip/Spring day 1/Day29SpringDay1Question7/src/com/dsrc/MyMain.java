package com.dsrc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.dsrc.beans.DepartmentBean;
import com.dsrc.beans.EmployeeBean;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	Resource resource = new ClassPathResource("context.xml");
	BeanFactory beanfactory= new XmlBeanFactory(resource);
	
	EmployeeBean bean2= (EmployeeBean) beanfactory.getBean("basic");
	System.out.println("Employee Details");
	System.out.println("EmpNo : " +bean2.getEmpno() + "  Name : " + bean2.getName() + " City: " + bean2.getCity());
	
	
	DepartmentBean db=(DepartmentBean) beanfactory.getBean("basic2");
	System.out.println("Department Details");
	System.out.println("DeptNo : " + db.getDeptno() + " Name : " + db.getDeptName());
	
	}
}


