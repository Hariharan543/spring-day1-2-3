package com.dsrc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.dsrc.config.ApplicationConfig;
import com.dsrc.spring.beans.MyBean;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
	MyBean bean = (MyBean) context.getBean("hello");
	// bean.setName("Hari");
	System.out.println(bean.getName());
}
}

