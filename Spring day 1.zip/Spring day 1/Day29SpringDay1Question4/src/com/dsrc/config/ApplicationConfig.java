package com.dsrc.config;

import org.springframework.context.annotation.Bean;

import com.dsrc.spring.beans.MyBean;

public class ApplicationConfig {
	
	@Bean(name = "hello")
	 public MyBean getBean() {
		return new MyBean("hari");
	 }

}
