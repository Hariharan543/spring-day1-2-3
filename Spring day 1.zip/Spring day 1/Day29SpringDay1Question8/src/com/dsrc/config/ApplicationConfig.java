package com.dsrc.config;

import org.springframework.context.annotation.Bean;

import com.dsrc.beans.DepartmentBean;
import com.dsrc.beans.EmployeeBean;

public class ApplicationConfig {

@Bean(name = "emp")
public EmployeeBean getBean() {
	return new EmployeeBean(101, "Hari", "NewYork");
}

@Bean(name="dept")
public DepartmentBean getBean1(){
	return new DepartmentBean();
}

}
