package com.dsrc;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.dsrc.beans.EmployeeBean;
import com.dsrc.config.ApplicationConfig;

import com.dsrc.beans.DepartmentBean;
import com.dsrc.beans.EmployeeBean;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
	EmployeeBean bean2 = (EmployeeBean) context.getBean("emp");
	
	//  bean.setName("Hari");   we can create here itself rather than declaring values in appconfi.java.. to do in appconfig.java we need to 
									// create parameterized constructor in bean cls for geting values
	
	System.out.println("Employee Details");
	System.out.println("EmpNo : " +bean2.getEmpno() + "  Name : " + bean2.getName() + " City: " + bean2.getCity());
	
	DepartmentBean deptbean =(DepartmentBean) context.getBean("dept");
	System.out.println("Employee Details");
	deptbean.setDeptno(10);
	deptbean.setDeptName("Sales");
	
	System.out.println("DeptNo: " + deptbean.getDeptno() + " Name:" + deptbean.getDeptName());
}
}
	
