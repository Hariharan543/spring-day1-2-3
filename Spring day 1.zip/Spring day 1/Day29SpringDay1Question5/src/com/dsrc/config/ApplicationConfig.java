package com.dsrc.config;

import org.springframework.context.annotation.Bean;

import com.dsrc.beans.NameBean;

public class ApplicationConfig {
	
	@Bean(name = "hello")
	 public NameBean getBean() {
		return new NameBean("hari");
	 }

}
