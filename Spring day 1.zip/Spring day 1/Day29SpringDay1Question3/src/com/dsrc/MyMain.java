package com.dsrc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.dsrc.beans.EmployeeBean;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	Resource resource = new ClassPathResource("context.xml");
	BeanFactory beanfactory= new XmlBeanFactory(resource);
	EmployeeBean bean2= (EmployeeBean) beanfactory.getBean("basic");
	System.out.println("no is:" +bean2.getEmpno());
	System.out.println("name is:" + bean2.getName());
	System.out.println("city is:" + bean2.getCity());
}
}

