package com.dsrc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.dsrc.beans.NameBean;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	Resource resource = new ClassPathResource("context.xml");
	BeanFactory beanfactory= new XmlBeanFactory(resource);
	NameBean bean2= (NameBean) beanfactory.getBean("basic");
	System.out.println("name is" + bean2.getName());
}
}
