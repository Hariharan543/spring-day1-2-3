package com.dsrc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.dsrc.beans.EmployeeBean;
import com.dsrc.config.ApplicationConfig;

public class MyMain 
{
public static void main(String[] args) {
	//Code to load Spring Bean..
	AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
	EmployeeBean bean = (EmployeeBean) context.getBean("hello");
	
	//  bean.setName("Hari");   we can create here itself rather than declaring values in appconfi.java.. to do in appconfig.java we need to 
									// create parameterized constructor in bean cls for geting values
	
	System.out.println(bean.getEmpno());
	System.out.println(bean.getName());
	System.out.println(bean.getCity());
	
	
}
}
