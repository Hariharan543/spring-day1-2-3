package com.dsrc.config;

import org.springframework.context.annotation.Bean;

import com.dsrc.beans.EmployeeBean;

public class ApplicationConfig {
	@Bean(name = "hello")
	 public EmployeeBean getBean() {
		return new EmployeeBean(101, "har", "Atlanta");
	 }

}
