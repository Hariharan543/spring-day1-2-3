package com.dsrc.dao;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.dsrc.bean.ChangePasswordBean;
import com.dsrc.bean.LoginBean;
import com.dsrc.bean.RegisterBean;

@Repository
public class ProfileManagementDAO {
	private HibernateTemplate hibernateTemplate;
	private SessionFactory sessionFactory;
	@Autowired
	public boolean validateLogin(LoginBean logBean)
	{
		// Do the logic for verifying the credentials with DB.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	public boolean registerUser(RegisterBean regBean)
	{
		
		// Do the logic for saving the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	public RegisterBean viewProfile(String loginname)
	{
		
		//Do the logic for return the bean filled with the details of the logged in user.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		return null;
		
	}
	
	public boolean editUser(RegisterBean regBean)
	{
		
		// Do the logic for modifying the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	public boolean changePassword(ChangePasswordBean cBean)
	{
		
		// Do the logic for  modifying the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	
}
