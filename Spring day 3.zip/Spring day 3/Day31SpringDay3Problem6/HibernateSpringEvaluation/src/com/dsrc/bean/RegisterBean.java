package com.dsrc.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Register")
public class RegisterBean 
{
	// Create the private variables for registration 
	// Create proper getters and Setters.
	// Use this bean for registration , view profile and update profiles functionalities..
	@Id
	@Column(name="loginid")
	private int loginid;
	
	@Column(name="name")
	private String name;
	
	@Column(name="age")
	private int age;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="contactnumber")
	private String contactnumber;
	
	@Column(name="password")
	private String password;
	
	@Column(name="email")
	private String email;
	
	public RegisterBean(){
	}
	
	public RegisterBean(int loginid, String name, int age, String gender, String contactnumber, String password, String email)
	{
		this.loginid=loginid;
		this.name=name;
		this.age=age;
		this.gender=gender;
		this.contactnumber=contactnumber;
		this.password=password;
		this.email=email;
		
	}

	public int getLoginid() {
		return loginid;
	}

	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
