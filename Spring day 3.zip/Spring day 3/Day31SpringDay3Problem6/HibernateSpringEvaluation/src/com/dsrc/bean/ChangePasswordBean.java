package com.dsrc.bean;

import javax.persistence.*;
@Entity
@Table(name="Changepassword")
public class ChangePasswordBean {

	/*  	Use this bean for password change .
	 *  Create variables for loginid ,old password , new password and confirm password
	 *  Create getters and setters..
	*/
	
	@Id
	@Column(name="loginid")
	private int loginid;
	
	@Column(name="oldpassword")
	private String oldpassword;
	
	@Column(name="newpassword")
	private String newpassword;
	
	public ChangePasswordBean(){
	}
	
	public ChangePasswordBean(int loginid, String oldpassword, String newpassword)
	{
		this.loginid=loginid;
		this.oldpassword=oldpassword;
		this.newpassword=newpassword;
		
	}

	public int getLoginid() {
		return loginid;
	}

	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}

	public String getOldpassword() {
		return oldpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	
}
