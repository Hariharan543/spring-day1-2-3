package com.dsrc.bean;
import javax.persistence.*;

@Entity
@Table(name="Login")
public class LoginBean 
{
	/*
	 * Create private variables for Login.
	 * Create getters and setters
	 * */
	@Id
	@Column(name="LoginId")
	private int loginid;
	
	@Column(name="Password")
	private String password;
	
	public LoginBean(){ 	}
	
	public LoginBean(int loginid, String password)
	{
		this.loginid=loginid;
		this.password=password;
		
	}

	public int getLoginid() {
		return loginid;
	}

	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
