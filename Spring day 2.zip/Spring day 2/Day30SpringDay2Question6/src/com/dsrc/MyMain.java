package com.dsrc;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.dsrc.beans.HelloWorld;
import com.dsrc.config.ApplicationConfig;



public class MyMain {
	
	public static void main(String[] args) {
		// Code to load Spring Bean..
	
			AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);	      
			HelloWorld obj = (HelloWorld) context.getBean("hello");
			obj.setMessage( "Hello World!");
		      obj.getMessage();
		      context.registerShutdownHook();
		}
	}