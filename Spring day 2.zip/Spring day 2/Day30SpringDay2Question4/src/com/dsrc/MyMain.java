package com.dsrc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.dsrc.beans.Employee;
import com.dsrc.config.ApplicationConfig;

public class MyMain {
	
	public static void main(String[] args) {
		// Code to load Spring Bean..
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

		 Employee object1=(Employee) context.getBean("mybean");
	        object1.setEmpno(101);
	        object1.setName("Mark");
	        object1.setCity("Washington");
	       
	       
	        Employee object2=(Employee) context.getBean("mybean");
	        object2.setEmpno(102);
	        object2.setName("Walter");
	        object2.setCity("Vienna");
	        
	     
	        System.out.println(object1);
	        System.out.println(object2);

	}
}
