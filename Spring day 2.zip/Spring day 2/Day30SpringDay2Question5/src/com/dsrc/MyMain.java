package com.dsrc;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dsrc.beans.HelloWorld;

public class MyMain {
	
	public static void main(String[] args) {
		// Code to load Spring Bean..


		AbstractApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		 HelloWorld obj = (HelloWorld) context.getBean("hw");
		   obj.getMessage();
		   context.registerShutdownHook();

	}
}




 