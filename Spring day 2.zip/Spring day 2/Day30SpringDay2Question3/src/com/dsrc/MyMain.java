package com.dsrc;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.dsrc.beans.Employee;



public class MyMain {
	
	public static void main(String[] args) {
		// Code to load Spring Bean..
		Resource resource = new ClassPathResource("context.xml");
		BeanFactory beanfactory= new XmlBeanFactory(resource);
		
		 Employee object1=(Employee) beanfactory.getBean("mybean");
	        object1.setEmpno(101);
	        object1.setName("Mark");
	        object1.setCity("Washington");
	       
	       
	        Employee object2=(Employee) beanfactory.getBean("mybean");
	        object2.setEmpno(102);
	        object2.setName("Walter");
	        object2.setCity("Vienna");
	        
	     
	        System.out.println(object1);
	        System.out.println(object2);
		
	}
}
