package com.dsrc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

import com.dsrc.beans.Employee;

public class ApplicationConfig {
	@Bean(name = "hello")
	@Scope("singleton")
	 public Employee getBean() {
		return new Employee();
	 }

}
