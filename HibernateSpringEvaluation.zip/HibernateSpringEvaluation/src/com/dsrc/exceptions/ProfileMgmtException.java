package com.dsrc.exceptions;

public class ProfileMgmtException {

	
	// Make the ProfileMgmtException class an exception class
	
	// Create a constructor to call its super class with error message passed as argument.
	
}
